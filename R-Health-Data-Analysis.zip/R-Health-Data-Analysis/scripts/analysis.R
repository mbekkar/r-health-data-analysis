# R Data Analysis - Health Dataset Exploration
# Author: Mounir Bekkar

library(tidyverse)
library(ggcorrplot)

set.seed(42)
n <- 1200

dir.create("data", showWarnings = FALSE)
dir.create("outputs/plots", recursive = TRUE, showWarnings = FALSE)

health_data <- tibble(
  id = 1:n,
  age = sample(18:75, n, replace = TRUE),
  gender = sample(c("Male", "Female"), n, replace = TRUE, prob = c(0.48, 0.52)),
  weight_kg = round(rnorm(n, mean = 75, sd = 15), 1),
  height_cm = round(rnorm(n, mean = 170, sd = 10), 1)
) %>%
  mutate(
    bmi = round(weight_kg / (height_cm / 100)^2, 1),
    cholesterol_mgdl = round(130 + age * 0.9 + bmi * 2.1 + rnorm(n, mean = 0, sd = 22), 0),
    systolic_bp = round(105 + age * 0.25 + bmi * 0.45 + rnorm(n, mean = 0, sd = 12), 0),
    diastolic_bp = round(70 + age * 0.12 + bmi * 0.25 + rnorm(n, mean = 0, sd = 8), 0),
    smoking = sample(c("Yes", "No"), n, replace = TRUE, prob = c(0.28, 0.72)),
    physical_activity = sample(c("Low", "Moderate", "High"), n, replace = TRUE, prob = c(0.35, 0.45, 0.20)),
    bmi_category = case_when(
      bmi < 18.5 ~ "Underweight",
      bmi < 25 ~ "Normal",
      bmi < 30 ~ "Overweight",
      TRUE ~ "Obese"
    )
  )

write_csv(health_data, "data/health_data.csv")

df_clean <- health_data %>%
  filter(
    bmi > 10 & bmi < 60,
    cholesterol_mgdl > 80 & cholesterol_mgdl < 350,
    systolic_bp > 80 & systolic_bp < 220,
    diastolic_bp > 45 & diastolic_bp < 140
  ) %>%
  mutate(
    bmi_category = factor(
      bmi_category,
      levels = c("Underweight", "Normal", "Overweight", "Obese")
    )
  )

p_bmi <- ggplot(df_clean, aes(x = bmi)) +
  geom_histogram(bins = 30, fill = "#fb923c", color = "white", alpha = 0.8) +
  geom_density(aes(y = after_stat(count)), color = "#f472b6", linewidth = 1.2) +
  theme_minimal() +
  labs(title = "BMI Distribution", x = "Body Mass Index", y = "Count")

p_cholesterol <- ggplot(df_clean, aes(x = cholesterol_mgdl)) +
  geom_histogram(bins = 30, fill = "#a78bfa", color = "white") +
  theme_minimal() +
  labs(title = "Cholesterol Distribution", x = "Cholesterol (mg/dL)", y = "Count")

p_bmi_cholesterol <- ggplot(df_clean, aes(x = bmi, y = cholesterol_mgdl, color = gender)) +
  geom_point(alpha = 0.7, size = 2.5) +
  geom_smooth(method = "lm", se = TRUE) +
  scale_color_manual(values = c("Male" = "#63b3ed", "Female" = "#f472b6")) +
  theme_minimal() +
  labs(title = "BMI vs Cholesterol Level", x = "BMI", y = "Cholesterol (mg/dL)")

p_age_cholesterol <- ggplot(df_clean, aes(x = age, y = cholesterol_mgdl)) +
  geom_point(alpha = 0.6, color = "#34d399") +
  geom_smooth(method = "lm", color = "#fb923c") +
  theme_minimal() +
  labs(title = "Age vs Cholesterol", x = "Age", y = "Cholesterol (mg/dL)")

p_boxplot <- df_clean %>%
  ggplot(aes(x = bmi_category, y = cholesterol_mgdl, fill = bmi_category)) +
  geom_boxplot(alpha = 0.8) +
  scale_fill_brewer(palette = "Oranges") +
  theme_minimal() +
  labs(title = "Cholesterol Level by BMI Category", x = "BMI Category", y = "Cholesterol (mg/dL)") +
  theme(legend.position = "none")

ggsave("outputs/plots/bmi_distribution.png", p_bmi, width = 10, height = 6)
ggsave("outputs/plots/cholesterol_distribution.png", p_cholesterol, width = 10, height = 6)
ggsave("outputs/plots/bmi_vs_cholesterol.png", p_bmi_cholesterol, width = 10, height = 6)
ggsave("outputs/plots/age_vs_cholesterol.png", p_age_cholesterol, width = 10, height = 6)
ggsave("outputs/plots/cholesterol_by_bmi_category.png", p_boxplot, width = 10, height = 6)

cor_matrix <- df_clean %>%
  select(age, bmi, cholesterol_mgdl, systolic_bp, diastolic_bp) %>%
  cor()

print(round(cor_matrix, 2))

summary_table <- df_clean %>%
  group_by(gender, bmi_category) %>%
  summarise(
    mean_bmi = round(mean(bmi), 2),
    mean_cholesterol = round(mean(cholesterol_mgdl), 1),
    mean_systolic_bp = round(mean(systolic_bp), 1),
    count = n(),
    .groups = "drop"
  ) %>%
  arrange(desc(mean_cholesterol))

print(summary_table)
